package ir.niniyar.app

import ir.niniyar.app.analytics.Analytics
import ir.niniyar.app.analytics.Analytics.H
import ir.niniyar.app.data.Event
import ir.niniyar.app.data.Type
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class AnalyticsTest {
    // A fixed "now": 15:00 today in the device time zone.
    private val today = Analytics.dayStart(0)
    private val now = today + 15 * H

    @Test
    fun sleepAcrossMidnightIsSplitBetweenDays() {
        val yesterday = Analytics.dayStart(1)
        // 23:00 yesterday -> 03:00 today
        val e = Event(type = Type.SLEEP, start = yesterday + 23 * H, end = today + 3 * H)
        val days = Analytics.dayStats(listOf(e), 2, 0, now)
        assertEquals(1 * H, days[0].night)   // yesterday: 23:00-24:00
        assertEquals(3 * H, days[1].night)   // today: 00:00-03:00
        assertEquals(0L, days[1].day)
    }

    @Test
    fun daytimeSleepCountsAsDay() {
        val e = Event(type = Type.SLEEP, start = today + 9 * H, end = today + 10 * H)
        val d = Analytics.dayStats(listOf(e), 1, 0, now)[0]
        assertEquals(H, d.day)
        assertEquals(0L, d.night)
    }

    @Test
    fun countsFeedsDiapersAndMl() {
        val ev = listOf(
            Event(type = Type.BREAST, start = today + 1 * H, end = today + 2 * H, side = "L"),
            Event(type = Type.BOTTLE, start = today + 3 * H, ml = 90, kind = "formula"),
            Event(type = Type.BOTTLE, start = today + 5 * H, ml = 60, kind = "expressed"),
            Event(type = Type.DIAPER, start = today + 6 * H, kind = "both"),
            Event(type = Type.DIAPER, start = today + 7 * H, kind = "wet")
        )
        val d = Analytics.dayStats(ev, 1, 0, now)[0]
        assertEquals(1, d.breast)
        assertEquals(2, d.bottle)
        assertEquals(150, d.ml)
        assertEquals(2, d.wet)
        assertEquals(1, d.dirty)
    }

    @Test
    fun feedIntervalNeedsEnoughData() {
        val few = listOf(
            Event(type = Type.BOTTLE, start = today + 1 * H, ml = 90),
            Event(type = Type.BOTTLE, start = today + 4 * H, ml = 90)
        )
        assertNull(Analytics.avgInterval(few, today))

        val many = (0..4).map { Event(type = Type.BOTTLE, start = today + (1 + it * 3) * H, ml = 90) }
        assertEquals(3 * H, Analytics.avgInterval(many, today))
    }

    @Test
    fun analyzeProducesWakeWindowAndNightStretch() {
        val ev = ArrayList<Event>()
        for (d in 3 downTo 0) {
            val a = Analytics.dayStart(d)
            ev.add(Event(type = Type.SLEEP, start = a + 9 * H, end = a + 10 * H))
            ev.add(Event(type = Type.SLEEP, start = a + 12 * H, end = a + 13 * H))
            ev.add(Event(type = Type.SLEEP, start = a + 21 * H, end = a + 24 * H))
        }
        val r = Analytics.analyze(ev, 4, now)
        assertNotNull(r.wake)
        assertNotNull(r.stretch)
        assertEquals(3 * H, r.stretch)
    }
}
