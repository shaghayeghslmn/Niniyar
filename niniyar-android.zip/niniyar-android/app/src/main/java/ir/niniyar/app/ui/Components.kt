package ir.niniyar.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import ir.niniyar.app.data.Event
import ir.niniyar.app.data.Type
import ir.niniyar.app.util.Fmt

@Composable
fun NCard(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(Modifier.padding(16.dp)) { content() }
    }
}

@Composable
fun Dot(color: Color) {
    Box(Modifier.size(9.dp).background(color, CircleShape))
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun <T> Seg(
    options: List<Pair<T, String>>,
    selected: T,
    onSelect: (T) -> Unit,
    modifier: Modifier = Modifier
) {
    SingleChoiceSegmentedButtonRow(modifier.fillMaxWidth()) {
        options.forEachIndexed { i, (value, label) ->
            SegmentedButton(
                selected = value == selected,
                onClick = { onSelect(value) },
                shape = SegmentedButtonDefaults.itemShape(i, options.size)
            ) { Text(label) }
        }
    }
}

class EvMeta(val emoji: String, val color: Color, val text: String)

@Composable
fun evMeta(e: Event): EvMeta {
    val t = LocalTones.current
    return when (e.type) {
        Type.BREAST -> EvMeta(
            "🤱", t.breast,
            "شیر مادر · سینه " + (if (e.side == "R") "راست" else "چپ") +
                (e.end?.let { " · " + Fmt.dur(it - e.start) } ?: "")
        )
        Type.BOTTLE -> EvMeta(
            "🍼", t.bottle,
            (if (e.kind == "expressed") "شیر دوشیده" else "شیر خشک") + " · ${Fmt.num(e.ml ?: 0)} میلی‌لیتر"
        )
        Type.SLEEP -> EvMeta("😴", t.sleep, "خواب · " + Fmt.dur((e.end ?: e.start) - e.start))
        Type.DIAPER -> EvMeta(
            "🧷", t.diaper,
            "پوشک · " + when (e.kind) { "wet" -> "خیس"; "dirty" -> "کثیف"; else -> "خیس و کثیف" }
        )
        else -> {
            val p = ArrayList<String>()
            e.weight?.let { p.add("وزن ${Fmt.num(it, 2)} کیلوگرم") }
            e.height?.let { p.add("قد ${Fmt.num(it, 1)} سانتی‌متر") }
            e.head?.let { p.add("دور سر ${Fmt.num(it, 1)}") }
            EvMeta("📏", t.growth, p.joinToString(" · "))
        }
    }
}
