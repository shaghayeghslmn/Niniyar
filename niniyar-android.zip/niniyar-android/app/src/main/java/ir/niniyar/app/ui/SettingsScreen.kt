package ir.niniyar.app.ui

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ir.niniyar.app.MainViewModel
import ir.niniyar.app.util.Fmt
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZoneOffset

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(vm: MainViewModel, contentPadding: PaddingValues) {
    val baby by vm.baby.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    fun toast(m: String) = Toast.makeText(ctx, m, Toast.LENGTH_SHORT).show()

    var name by remember(baby.name) { mutableStateOf(baby.name) }
    var birth by remember(baby.birth) { mutableStateOf(baby.birth) }
    var showPicker by remember { mutableStateOf(false) }
    var backup by remember { mutableStateOf("") }
    var wipeArmed by remember { mutableStateOf(false) }

    if (showPicker) {
        val st = rememberDatePickerState()
        DatePickerDialog(
            onDismissRequest = { showPicker = false },
            confirmButton = {
                TextButton({
                    st.selectedDateMillis?.let {
                        birth = java.time.Instant.ofEpochMilli(it).atZone(ZoneOffset.UTC).toLocalDate().toString()
                    }
                    showPicker = false
                }) { Text("تأیید") }
            },
            dismissButton = { TextButton({ showPicker = false }) { Text("انصراف") } }
        ) { DatePicker(state = st) }
    }

    LazyColumn(
        contentPadding = PaddingValues(
            start = 14.dp, end = 14.dp,
            top = contentPadding.calculateTopPadding() + 10.dp,
            bottom = contentPadding.calculateBottomPadding() + 16.dp
        ),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Text("تنظیمات", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(horizontal = 4.dp)) }

        item {
            NCard {
                Text("مشخصات کودک", fontWeight = FontWeight.Bold)
                OutlinedTextField(
                    name, { name = it }, label = { Text("نام") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(top = 10.dp)
                )
                val pretty = runCatching {
                    Fmt.dateLong(LocalDate.parse(birth).atTime(12, 0).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli())
                }.getOrNull()
                OutlinedButton({ showPicker = true }, Modifier.fillMaxWidth().padding(top = 8.dp)) {
                    Text(if (pretty != null) "تاریخ تولد: $pretty · ${babyAge(birth)}" else "انتخاب تاریخ تولد")
                }
                Button({ vm.setBaby(name.trim(), birth); toast("ذخیره شد") }, Modifier.fillMaxWidth().padding(top = 8.dp)) { Text("ذخیره") }
            }
        }

        item {
            NCard {
                Text("پشتیبان‌گیری و انتقال", fontWeight = FontWeight.Bold)
                Text(
                    "داده‌ها فقط روی همین گوشی ذخیره می‌شوند. برای انتقال، پشتیبان را کپی کنید و روی دستگاه دیگر بازیابی کنید.",
                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 6.dp)
                )
                OutlinedTextField(
                    backup, { backup = it }, label = { Text("متن پشتیبان") }, minLines = 3, maxLines = 5,
                    textStyle = MaterialTheme.typography.bodySmall.copy(textAlign = TextAlign.Left),
                    modifier = Modifier.fillMaxWidth()
                )
                Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton({
                        backup = vm.exportJson(); clip.setText(AnnotatedString(backup)); toast("پشتیبان کپی شد")
                    }, Modifier.weight(1f)) { Text("ساخت و کپی") }
                    OutlinedButton({
                        if (vm.importJson(backup)) toast("بازیابی شد") else toast("متن پشتیبان معتبر نیست")
                    }, Modifier.weight(1f)) { Text("بازیابی") }
                }
            }
        }

        item {
            NCard {
                Text("داده‌ها", fontWeight = FontWeight.Bold)
                OutlinedButton({ vm.loadDemo(); toast("داده نمونه بارگذاری شد") }, Modifier.fillMaxWidth().padding(top = 8.dp)) {
                    Text("بارگذاری داده نمونه (۱۴ روز)")
                }
                OutlinedButton({
                    if (wipeArmed) { vm.wipe(); wipeArmed = false; toast("همه ثبت‌ها پاک شد") } else wipeArmed = true
                }, Modifier.fillMaxWidth().padding(top = 8.dp)) {
                    Text(if (wipeArmed) "برای پاک کردن دوباره بزنید" else "پاک کردن همه ثبت‌ها", color = MaterialTheme.colorScheme.error)
                }
            }
        }

        item {
            Text(
                "نمونه اولیه · این برنامه جایگزین مشاوره پزشکی نیست.", fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
            )
        }
    }
}
