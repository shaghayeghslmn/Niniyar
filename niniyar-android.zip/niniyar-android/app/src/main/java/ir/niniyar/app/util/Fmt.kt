package ir.niniyar.app.util

import android.icu.text.NumberFormat
import android.icu.text.SimpleDateFormat
import android.icu.util.ULocale
import java.util.Date
import kotlin.math.roundToInt

/** Persian digits, Jalali (Persian-calendar) dates and Persian duration text. */
object Fmt {
    private val fa = ULocale("fa_IR")
    private val jalali = ULocale("fa_IR@calendar=persian")

    fun num(n: Number, digits: Int = 0): String {
        val f = NumberFormat.getInstance(fa)
        f.maximumFractionDigits = digits
        f.minimumFractionDigits = 0
        f.isGroupingUsed = false
        return f.format(n.toDouble())
    }

    fun two(n: Int): String = if (n < 10) "۰" + num(n) else num(n)

    fun time(ms: Long): String = SimpleDateFormat("HH:mm", fa).format(Date(ms))
    fun dayFull(ms: Long): String = SimpleDateFormat("EEEE d MMMM", jalali).format(Date(ms))
    fun dayShort(ms: Long): String = SimpleDateFormat("d/M", jalali).format(Date(ms))
    fun dateLong(ms: Long): String = SimpleDateFormat("d MMMM y", jalali).format(Date(ms))

    fun dur(ms: Long): String {
        val m = (ms / 60000.0).roundToInt().coerceAtLeast(0)
        val h = m / 60
        val mm = m % 60
        return if (h == 0) "${num(mm)} دقیقه"
        else "${num(h)} ساعت" + if (mm > 0) " و ${num(mm)} دقیقه" else ""
    }

    fun hrs(ms: Long, digits: Int = 1): String = "${num(ms / 3_600_000.0, digits)} ساعت"

    fun clock(ms: Long): String {
        val t = (ms / 1000).coerceAtLeast(0)
        val h = (t / 3600).toInt()
        val m = (t % 3600 / 60).toInt()
        val s = (t % 60).toInt()
        return (if (h > 0) num(h) + ":" else "") + two(m) + ":" + two(s)
    }

    /** Accepts Persian/Arabic digits and decimal separators from any keyboard. */
    fun parse(s: String): Double? {
        val sb = StringBuilder()
        for (c in s.trim()) {
            when (c) {
                in '۰'..'۹' -> sb.append('0' + (c - '۰'))
                in '٠'..'٩' -> sb.append('0' + (c - '٠'))
                '٫', '،', ',' -> sb.append('.')
                else -> sb.append(c)
            }
        }
        return sb.toString().toDoubleOrNull()
    }
}
