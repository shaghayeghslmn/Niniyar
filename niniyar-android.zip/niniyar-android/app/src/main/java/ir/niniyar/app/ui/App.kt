package ir.niniyar.app.ui

import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import ir.niniyar.app.MainViewModel

@Composable
fun App(vm: MainViewModel = viewModel()) {
    var tab by rememberSaveable { mutableStateOf(0) }
    var sheet by remember { mutableStateOf<SheetKind?>(null) }

    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(tab == 0, { tab = 0 }, { Text("🌙", fontSize = 20.sp) }, label = { Text("امروز") })
                NavigationBarItem(tab == 1, { tab = 1 }, { Text("📈", fontSize = 20.sp) }, label = { Text("تحلیل") })
                NavigationBarItem(tab == 2, { tab = 2 }, { Text("⚙️", fontSize = 20.sp) }, label = { Text("تنظیمات") })
            }
        }
    ) { pad ->
        when (tab) {
            0 -> TodayScreen(vm, pad) { sheet = it }
            1 -> InsightsScreen(vm, pad)
            else -> SettingsScreen(vm, pad)
        }
    }

    sheet?.let { LogSheet(it, vm) { sheet = null } }
}
