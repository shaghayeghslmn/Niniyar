package ir.niniyar.app.analytics

import ir.niniyar.app.analytics.Analytics.H
import ir.niniyar.app.data.Event
import ir.niniyar.app.data.Type
import kotlin.random.Random

/** Fourteen days of plausible newborn data, used to preview the analytics. */
object Demo {
    fun events(now: Long = System.currentTimeMillis(), rnd: Random = Random.Default): List<Event> {
        val out = ArrayList<Event>()
        fun add(e: Event) { if ((e.end ?: e.start) <= now) out.add(e) }
        fun r(lo: Double, hi: Double) = lo + rnd.nextDouble() * (hi - lo)
        val m = 60_000L

        for (i in 13 downTo 0) {
            val a = Analytics.dayStart(i, now)
            val prog = (13 - i) / 13.0
            var t = a + (r(5.2, 6.0) * H).toLong()
            var n = 0
            while (t < a + (23.3 * H).toLong()) {
                if (rnd.nextDouble() < 0.3 + 0.1 * prog) {
                    add(Event(type = Type.BOTTLE, start = t, ml = (70 + prog * 40 + r(0.0, 25.0)).toInt(),
                        kind = if (rnd.nextBoolean()) "formula" else "expressed"))
                } else {
                    add(Event(type = Type.BREAST, start = t, end = t + (r(12.0, 26.0) * m).toLong(),
                        side = if (n % 2 == 0) "L" else "R"))
                }
                if (rnd.nextDouble() < 0.8) {
                    val kind = when { rnd.nextDouble() < 0.3 -> "dirty"; rnd.nextDouble() < 0.12 -> "both"; else -> "wet" }
                    add(Event(type = Type.DIAPER, start = t + (r(10.0, 35.0) * m).toLong(), kind = kind))
                }
                t += ((2.3 + rnd.nextDouble() * 1.1 + prog * 0.35) * H).toLong()
                n++
            }
            listOf(8.3 to 0.9, 11.6 to 1.5, 15.1 to 1.1, 18.0 to 0.6).forEach { (hour, len) ->
                if (rnd.nextDouble() < 0.9) {
                    val s = a + ((hour + r(-0.35, 0.35)) * H).toLong()
                    add(Event(type = Type.SLEEP, start = s, end = s + ((len + r(0.0, 0.6)) * 0.9 * H).toLong()))
                }
            }
            val ns = a + (r(21.2, 21.8) * H).toLong()
            val stretch = ((2.6 + prog * 1.7 + r(0.0, 0.5)) * H).toLong()
            add(Event(type = Type.SLEEP, start = ns, end = ns + stretch))
            val s2 = ns + stretch + (0.4 * H).toLong()
            add(Event(type = Type.SLEEP, start = s2, end = s2 + (r(2.2, 3.0) * H).toLong()))
            if (rnd.nextDouble() < 0.8 - prog * 0.5) {
                val fn = ns + stretch
                add(Event(type = Type.BREAST, start = fn, end = fn + 15 * m, side = "L"))
            }
        }
        listOf(Triple(13, 4.15, 54.5), Triple(7, 4.55, 55.8), Triple(0, 4.95, 57.0)).forEach { (d, w, h) ->
            val ts = Analytics.dayStart(d, now) + 10 * H
            add(Event(type = Type.GROWTH, start = ts, weight = w, height = h, head = 36.5 + (13 - d) * 0.1))
        }
        return out
    }
}
