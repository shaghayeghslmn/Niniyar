package ir.niniyar.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

object Type {
    const val BREAST = "breast"
    const val BOTTLE = "bottle"
    const val SLEEP = "sleep"
    const val DIAPER = "diaper"
    const val GROWTH = "growth"
}

/** One logged moment. [end] is set for breastfeeding and sleep. */
@Entity(tableName = "events")
data class Event(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: String,
    val start: Long,
    val end: Long? = null,
    val side: String? = null,      // "L" or "R" (breast)
    val ml: Int? = null,           // bottle amount
    val kind: String? = null,      // bottle: formula|expressed, diaper: wet|dirty|both
    val weight: Double? = null,    // kg
    val height: Double? = null,    // cm
    val head: Double? = null       // cm
)

data class Baby(val name: String = "", val birth: String = "") // birth: yyyy-MM-dd or ""

data class Timers(
    val sleepStart: Long? = null,
    val breastStart: Long? = null,
    val breastSide: String? = null
)
