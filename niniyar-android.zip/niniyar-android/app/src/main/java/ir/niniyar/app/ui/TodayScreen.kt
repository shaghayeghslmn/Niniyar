package ir.niniyar.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ir.niniyar.app.MainViewModel
import ir.niniyar.app.analytics.Analytics
import ir.niniyar.app.data.Event
import ir.niniyar.app.data.Type
import ir.niniyar.app.util.Fmt
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.temporal.ChronoUnit

enum class SheetKind { BREAST, BOTTLE, SLEEP, DIAPER, GROWTH }

fun babyAge(birth: String): String {
    val b = runCatching { LocalDate.parse(birth) }.getOrNull() ?: return ""
    val days = ChronoUnit.DAYS.between(b, LocalDate.now())
    return when {
        days < 0 -> ""
        days < 14 -> "${Fmt.num(days)} روزه"
        days < 84 -> "${Fmt.num(days / 7)} هفته و ${Fmt.num(days % 7)} روزه"
        else -> "${Fmt.num((days / 30.44).toInt())} ماهه"
    }
}

@Composable
fun TodayScreen(vm: MainViewModel, contentPadding: PaddingValues, onOpen: (SheetKind) -> Unit) {
    val events by vm.events.collectAsStateWithLifecycle()
    val timers by vm.timers.collectAsStateWithLifecycle()
    val baby by vm.baby.collectAsStateWithLifecycle()
    val tones = LocalTones.current
    val running = timers.sleepStart != null || timers.breastStart != null
    val tick = if (running) 1000L else 30_000L
    val now by produceState(System.currentTimeMillis(), tick) {
        while (true) { value = System.currentTimeMillis(); delay(tick) }
    }

    val a = Analytics.dayStart(0, now)
    val today = events.filter { it.start >= a }
    val feeds = today.count { Analytics.isFeed(it) }
    val diapers = today.count { it.type == Type.DIAPER }
    var sleepMs = events.filter { it.type == Type.SLEEP && it.end != null }
        .sumOf { Analytics.overlap(it.start, it.end ?: it.start, a, now) }
    timers.sleepStart?.let { sleepMs += now - maxOf(a, it) }
    val lastFeed = Analytics.lastFeed(events)
    val interval = Analytics.avgInterval(events, Analytics.dayStart(7, now))

    LazyColumn(
        contentPadding = PaddingValues(
            start = 14.dp, end = 14.dp,
            top = contentPadding.calculateTopPadding() + 10.dp,
            bottom = contentPadding.calculateBottomPadding() + 16.dp
        ),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column(Modifier.padding(horizontal = 4.dp)) {
                Text(
                    baby.name.ifBlank { "نی‌نی‌یار" }, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold
                )
                val age = babyAge(baby.birth)
                Text(
                    Fmt.dayFull(now) + if (age.isNotEmpty()) " · $age" else "",
                    fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        timers.sleepStart?.let { s ->
            item { TimerBanner("در حال خواب", Fmt.clock(now - s), tones.night, "بیدار شد") { vm.stopSleep() } }
        }
        timers.breastStart?.let { s ->
            item {
                TimerBanner(
                    "شیردهی · سینه " + if (timers.breastSide == "R") "راست" else "چپ",
                    Fmt.clock(now - s), tones.breast, "پایان"
                ) { vm.stopBreast() }
            }
        }

        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                QuickAction("🤱", "شیر مادر", Modifier.weight(1f)) { onOpen(SheetKind.BREAST) }
                QuickAction("🍼", "شیشه", Modifier.weight(1f)) { onOpen(SheetKind.BOTTLE) }
                QuickAction("😴", "خواب", Modifier.weight(1f)) { onOpen(SheetKind.SLEEP) }
                QuickAction("🧷", "پوشک", Modifier.weight(1f)) { onOpen(SheetKind.DIAPER) }
                QuickAction("📏", "رشد", Modifier.weight(1f)) { onOpen(SheetKind.GROWTH) }
            }
        }

        item {
            NCard {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    DayRing(events, timers.sleepStart, now)
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Stat("${Fmt.num(feeds)} بار", "شیردهی امروز", tones.breast)
                        Stat(Fmt.hrs(sleepMs), "خواب امروز", tones.sleep)
                        Stat("${Fmt.num(diapers)} بار", "تعویض پوشک", tones.diaper)
                    }
                }
            }
        }

        if (lastFeed != null) {
            item {
                NCard {
                    Row(Modifier.fillMaxWidth()) {
                        Column(Modifier.weight(1f)) {
                            Muted("آخرین شیردهی")
                            Text(Fmt.dur(now - lastFeed.start) + " پیش", fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
                        }
                        if (interval != null) {
                            val next = lastFeed.start + interval
                            Column(Modifier.weight(1f)) {
                                Muted("تخمین نوبت بعد")
                                Text(
                                    if (next > now) "حدود " + Fmt.time(next) else "احتمالاً الان",
                                    fontSize = 17.sp, fontWeight = FontWeight.ExtraBold
                                )
                            }
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Muted(
                        if (interval != null) "تخمین بر پایه میانگین فاصله شیردهی‌های هفته گذشته (${Fmt.dur(interval)}) است."
                        else "با ثبت چند شیردهی دیگر، تخمین نوبت بعد هم نمایش داده می‌شود.",
                        size = 12
                    )
                }
            }
        }

        item {
            NCard {
                Text("ثبت‌های امروز", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                if (today.isEmpty()) Muted("هنوز چیزی ثبت نشده. از دکمه‌های بالا شروع کنید.")
                today.forEach { e -> TimelineRow(e) { vm.delete(e.id) } }
            }
        }
    }
}

@Composable
private fun Muted(text: String, size: Int = 13) {
    Text(text, fontSize = size.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable
private fun Stat(value: String, label: String, dot: Color) {
    Column {
        Text(value, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Dot(dot)
            Muted(label, 12)
        }
    }
}

@Composable
private fun QuickAction(emoji: String, label: String, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surface)
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(emoji, fontSize = 22.sp)
        Text(label, fontSize = 11.sp)
    }
}

@Composable
private fun TimerBanner(title: String, clock: String, color: Color, action: String, onStop: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(color).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 12.sp, color = Color.White)
            Text(clock, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
        }
        TextButton(onClick = onStop) { Text(action, color = Color.White, fontWeight = FontWeight.Bold) }
    }
}

@Composable
private fun TimelineRow(e: Event, onDelete: () -> Unit) {
    val m = evMeta(e)
    var armed by remember { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(34.dp).clip(RoundedCornerShape(11.dp)).background(m.color.copy(alpha = 0.16f)),
            contentAlignment = Alignment.Center
        ) { Text(m.emoji, fontSize = 17.sp) }
        Spacer(Modifier.size(10.dp))
        Text(m.text, Modifier.weight(1f), fontSize = 14.sp)
        Muted(Fmt.time(e.start), 12)
        TextButton(onClick = { if (armed) onDelete() else armed = true }) {
            Text(
                if (armed) "مطمئنید؟" else "حذف", fontSize = 12.sp,
                color = if (armed) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
