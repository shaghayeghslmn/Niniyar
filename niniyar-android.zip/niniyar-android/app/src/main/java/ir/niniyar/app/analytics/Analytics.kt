package ir.niniyar.app.analytics

import ir.niniyar.app.data.Event
import ir.niniyar.app.data.Type
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.ChronoUnit

/** Pure functions over the event list. No Android dependencies, so they are unit-testable. */
object Analytics {
    const val H = 3_600_000L
    const val MIN = 60_000L

    private val zone: ZoneId get() = ZoneId.systemDefault()

    fun dayStart(offset: Int = 0, now: Long = System.currentTimeMillis()): Long =
        Instant.ofEpochMilli(now).atZone(zone).toLocalDate().minusDays(offset.toLong())
            .atStartOfDay(zone).toInstant().toEpochMilli()

    fun nextDay(a: Long): Long =
        Instant.ofEpochMilli(a).atZone(zone).toLocalDate().plusDays(1)
            .atStartOfDay(zone).toInstant().toEpochMilli()

    fun hourOf(ts: Long): Int = Instant.ofEpochMilli(ts).atZone(zone).hour

    fun overlap(s: Long, e: Long, a: Long, b: Long): Long = maxOf(0L, minOf(e, b) - maxOf(s, a))

    fun isFeed(e: Event) = e.type == Type.BREAST || e.type == Type.BOTTLE

    data class Day(
        val start: Long,
        val night: Long,   // sleep between 19:00 and 07:00
        val day: Long,     // sleep between 07:00 and 19:00
        val breast: Int,
        val bottle: Int,
        val ml: Int,
        val wet: Int,
        val dirty: Int,
        val has: Boolean
    )

    /** Oldest day first. [offset] shifts the window back by that many days. */
    fun dayStats(ev: List<Event>, n: Int, offset: Int, now: Long): List<Day> {
        val out = ArrayList<Day>()
        for (i in (n - 1 + offset) downTo offset) {
            val a = dayStart(i, now)
            val b = nextDay(a)
            var night = 0L; var day = 0L
            var br = 0; var bo = 0; var ml = 0; var wet = 0; var dirty = 0
            var has = false
            for (e in ev) {
                if (e.type == Type.SLEEP) {
                    val end = e.end ?: continue
                    val nt = overlap(e.start, end, a, a + 7 * H) + overlap(e.start, end, a + 19 * H, b)
                    val dy = overlap(e.start, end, a + 7 * H, a + 19 * H)
                    if (nt + dy > 0) { night += nt; day += dy; has = true }
                } else if (e.start >= a && e.start < b) {
                    has = true
                    when (e.type) {
                        Type.BREAST -> br++
                        Type.BOTTLE -> { bo++; ml += e.ml ?: 0 }
                        Type.DIAPER -> {
                            if (e.kind == "wet" || e.kind == "both") wet++
                            if (e.kind == "dirty" || e.kind == "both") dirty++
                        }
                    }
                }
            }
            out.add(Day(a, night, day, br, bo, ml, wet, dirty, has))
        }
        return out
    }

    /** Mean gap between feeds since [since]; null when there are fewer than 3 usable gaps. */
    fun avgInterval(ev: List<Event>, since: Long): Long? {
        val f = ev.filter { isFeed(it) && it.start >= since }.sortedBy { it.start }
        val diffs = (1 until f.size).map { f[it].start - f[it - 1].start }
            .filter { it in (20 * MIN)..(10 * H) }
        return if (diffs.size >= 3) diffs.sum() / diffs.size else null
    }

    class Report(
        val days: List<Day>,
        val activeDays: Int,
        val sleepAvg: Long,
        val prevSleepAvg: Long?,
        val feedsAvg: Double,
        val prevFeedsAvg: Double?,
        val mlAvg: Double,
        val diaperAvg: Double,
        val interval: Long?,
        val wake: Long?,
        val stretch: Long?,
        val sleepByHour: LongArray,
        val feedsByHour: IntArray
    )

    fun analyze(ev: List<Event>, n: Int, now: Long = System.currentTimeMillis()): Report {
        val cur = dayStats(ev, n, 0, now)
        val prev = dayStats(ev, n, n, now)
        val act = cur.filter { it.has }
        val pact = prev.filter { it.has }
        val k = maxOf(act.size, 1)
        val pk = maxOf(pact.size, 1)
        fun sl(d: Day) = d.night + d.day

        val since = dayStart(n - 1, now)
        val sleeps = ev.filter { it.type == Type.SLEEP && it.end != null && it.start >= since }
            .sortedBy { it.start }

        // wake windows: gap between the end of one sleep and the start of the next
        val wakes = (1 until sleeps.size).map { sleeps[it].start - (sleeps[it - 1].end ?: 0L) }
            .filter { it in (10 * MIN)..(6 * H) }

        // longest night sleep per night (sessions starting 19:00-04:00)
        val nights = HashMap<LocalDate, Long>()
        for (e in sleeps) {
            val h = hourOf(e.start)
            if (h >= 19 || h < 4) {
                val key = Instant.ofEpochMilli(e.start - 5 * H).atZone(zone).toLocalDate()
                nights[key] = maxOf(nights[key] ?: 0L, (e.end ?: e.start) - e.start)
            }
        }

        // hour-of-day profile
        val sh = LongArray(24)
        for (e in sleeps) {
            val end = e.end ?: continue
            var t = e.start
            while (t < end) {
                val z = Instant.ofEpochMilli(t).atZone(zone)
                val hourEnd = z.truncatedTo(ChronoUnit.HOURS).plusHours(1).toInstant().toEpochMilli()
                val seg = minOf(end, hourEnd)
                sh[z.hour] += seg - t
                t = seg
            }
        }
        val fh = IntArray(24)
        for (e in ev) if (isFeed(e) && e.start >= since) fh[hourOf(e.start)]++

        return Report(
            days = cur,
            activeDays = act.size,
            sleepAvg = act.sumOf { sl(it) } / k,
            prevSleepAvg = if (pact.size >= 3) pact.sumOf { sl(it) } / pk else null,
            feedsAvg = act.sumOf { it.breast + it.bottle }.toDouble() / k,
            prevFeedsAvg = if (pact.size >= 3) pact.sumOf { it.breast + it.bottle }.toDouble() / pk else null,
            mlAvg = act.sumOf { it.ml }.toDouble() / k,
            diaperAvg = act.sumOf { it.wet + it.dirty }.toDouble() / k,
            interval = avgInterval(ev, since),
            wake = if (wakes.size >= 3) wakes.sum() / wakes.size else null,
            stretch = if (nights.size >= 2) nights.values.sum() / nights.size else null,
            sleepByHour = sh,
            feedsByHour = fh
        )
    }

    fun lastFeed(ev: List<Event>): Event? = ev.filter { isFeed(it) }.maxByOrNull { it.start }
}
