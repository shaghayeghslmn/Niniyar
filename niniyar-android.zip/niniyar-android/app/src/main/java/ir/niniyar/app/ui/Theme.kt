package ir.niniyar.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

/** Colors that carry meaning across the app: one per kind of log entry. */
@Immutable
class Tones(
    val sleep: Color, val night: Color, val breast: Color, val bottle: Color,
    val diaper: Color, val growth: Color, val ring: Color
)

val LightTones = Tones(
    sleep = Color(0xFF6F78F0), night = Color(0xFF3D44B8), breast = Color(0xFFE0558A),
    bottle = Color(0xFFE59A2E), diaper = Color(0xFF27A384), growth = Color(0xFF2F8AD8),
    ring = Color(0xFFDFE5EE)
)
val DarkTones = Tones(
    sleep = Color(0xFF8D95FF), night = Color(0xFF6670E8), breast = Color(0xFFF07AA5),
    bottle = Color(0xFFF2B155), diaper = Color(0xFF45C4A4), growth = Color(0xFF5AA9EE),
    ring = Color(0xFF2A3350)
)

val LocalTones = staticCompositionLocalOf { LightTones }

@Composable
fun NiniTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val scheme = if (dark) darkColorScheme(
        primary = Color(0xFF8A90FF), onPrimary = Color(0xFF0F1420),
        background = Color(0xFF0F1420), onBackground = Color(0xFFE8ECF6),
        surface = Color(0xFF181F30), onSurface = Color(0xFFE8ECF6),
        surfaceVariant = Color(0xFF252B52), onSurfaceVariant = Color(0xFF97A1B8),
        outlineVariant = Color(0xFF273049), error = Color(0xFFEF7A73)
    ) else lightColorScheme(
        primary = Color(0xFF4F55D4), onPrimary = Color.White,
        background = Color(0xFFEEF2F7), onBackground = Color(0xFF1C2333),
        surface = Color.White, onSurface = Color(0xFF1C2333),
        surfaceVariant = Color(0xFFE6E7FB), onSurfaceVariant = Color(0xFF6D7689),
        outlineVariant = Color(0xFFE1E7F0), error = Color(0xFFC8423B)
    )
    CompositionLocalProvider(
        LocalTones provides (if (dark) DarkTones else LightTones),
        LocalLayoutDirection provides LayoutDirection.Rtl
    ) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
