package ir.niniyar.app.ui

import android.widget.Toast
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ir.niniyar.app.MainViewModel
import ir.niniyar.app.util.Fmt

private val AGO = listOf(0 to "الان", 15 to "۱۵ دقیقه پیش", 30 to "۳۰ دقیقه پیش", 60 to "۱ ساعت پیش", 120 to "۲ ساعت پیش")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LogSheet(kind: SheetKind, vm: MainViewModel, onDismiss: () -> Unit) {
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val ctx = LocalContext.current
    val events by vm.events.collectAsStateWithLifecycle()
    val timers by vm.timers.collectAsStateWithLifecycle()
    fun warn(msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = state) {
        Column(
            Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            when (kind) {
                SheetKind.BREAST -> {
                    Title("🤱 شیر مادر")
                    var side by remember { mutableStateOf("L") }
                    var min by remember { mutableStateOf("") }
                    Seg(listOf("L" to "سینه چپ", "R" to "سینه راست"), side, { side = it })
                    Button({ vm.startBreast(side); onDismiss() }, Modifier.fillMaxWidth()) { Text("شروع تایمر") }
                    Muted("یا مدت را دستی ثبت کنید")
                    NumberField("مدت (دقیقه)", min) { min = it }
                    OutlinedButton({
                        val m = Fmt.parse(min)
                        if (m == null || m <= 0) warn("مدت را وارد کنید") else { vm.addBreastManual(side, m); onDismiss() }
                    }, Modifier.fillMaxWidth()) { Text("ثبت (پایان: همین الان)") }
                }

                SheetKind.SLEEP -> {
                    Title("😴 خواب")
                    var min by remember { mutableStateOf("") }
                    if (timers.sleepStart == null) {
                        Button({ vm.startSleep(); onDismiss() }, Modifier.fillMaxWidth()) { Text("خوابید، شروع تایمر") }
                    } else Muted("یک خواب در حال ثبت است؛ از صفحه اصلی پایانش دهید.")
                    Muted("یا مدت را دستی ثبت کنید")
                    NumberField("مدت (دقیقه)", min) { min = it }
                    OutlinedButton({
                        val m = Fmt.parse(min)
                        if (m == null || m <= 0) warn("مدت را وارد کنید") else { vm.addSleepManual(m); onDismiss() }
                    }, Modifier.fillMaxWidth()) { Text("ثبت (پایان: همین الان)") }
                }

                SheetKind.BOTTLE -> {
                    Title("🍼 شیشه")
                    val last = events.firstOrNull { it.type == "bottle" }
                    var type by remember { mutableStateOf("formula") }
                    var ml by remember { mutableStateOf(Fmt.num(last?.ml ?: 90)) }
                    var ago by remember { mutableStateOf(0) }
                    Seg(listOf("formula" to "شیر خشک", "expressed" to "شیر دوشیده"), type, { type = it })
                    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton({ ml = Fmt.num(((Fmt.parse(ml) ?: 0.0) - 10).coerceAtLeast(0.0)) }) { Text("−") }
                        NumberField("میلی‌لیتر", ml, Modifier.weight(1f)) { ml = it }
                        OutlinedButton({ ml = Fmt.num((Fmt.parse(ml) ?: 0.0) + 10) }) { Text("+") }
                    }
                    AgeChips(ago) { ago = it }
                    Button({
                        val v = Fmt.parse(ml)
                        if (v == null || v <= 0) warn("مقدار را وارد کنید") else { vm.addBottle(type, v.toInt(), ago); onDismiss() }
                    }, Modifier.fillMaxWidth()) { Text("ثبت") }
                }

                SheetKind.DIAPER -> {
                    Title("🧷 پوشک")
                    var ago by remember { mutableStateOf(0) }
                    AgeChips(ago) { ago = it }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button({ vm.addDiaper("wet", ago); onDismiss() }, Modifier.weight(1f)) { Text("💧 خیس") }
                        Button({ vm.addDiaper("dirty", ago); onDismiss() }, Modifier.weight(1f)) { Text("💩 کثیف") }
                        Button({ vm.addDiaper("both", ago); onDismiss() }, Modifier.weight(1f)) { Text("هر دو") }
                    }
                }

                SheetKind.GROWTH -> {
                    Title("📏 رشد")
                    var w by remember { mutableStateOf("") }
                    var h by remember { mutableStateOf("") }
                    var hc by remember { mutableStateOf("") }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        NumberField("وزن (کیلوگرم)", w, Modifier.weight(1f)) { w = it }
                        NumberField("قد (سانتی‌متر)", h, Modifier.weight(1f)) { h = it }
                    }
                    NumberField("دور سر (سانتی‌متر)", hc) { hc = it }
                    Button({
                        val vw = Fmt.parse(w)?.takeIf { it > 0 }
                        val vh = Fmt.parse(h)?.takeIf { it > 0 }
                        val vc = Fmt.parse(hc)?.takeIf { it > 0 }
                        if (vw == null && vh == null && vc == null) warn("دست‌کم یک مقدار وارد کنید")
                        else { vm.addGrowth(vw, vh, vc); onDismiss() }
                    }, Modifier.fillMaxWidth()) { Text("ثبت") }
                }
            }
        }
    }
}

@Composable
private fun Title(text: String) = Text(text, fontSize = 17.sp, fontWeight = FontWeight.Bold)

@Composable
private fun Muted(text: String) = Text(text, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

@Composable
private fun NumberField(label: String, value: String, modifier: Modifier = Modifier.fillMaxWidth(), onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) }, singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = modifier
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AgeChips(selected: Int, onSelect: (Int) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        AGO.forEach { (min, label) ->
            FilterChip(selected = selected == min, onClick = { onSelect(min) }, label = { Text(label) })
        }
    }
}
