package ir.niniyar.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import ir.niniyar.app.analytics.Analytics
import ir.niniyar.app.analytics.Demo
import ir.niniyar.app.data.AppDatabase
import ir.niniyar.app.data.Baby
import ir.niniyar.app.data.Event
import ir.niniyar.app.data.Timers
import ir.niniyar.app.data.Type
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val dao = Room.databaseBuilder(app, AppDatabase::class.java, "niniyar.db").build().events()
    private val prefs = app.getSharedPreferences("niniyar", 0)

    val events: StateFlow<List<Event>> =
        dao.all().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val _timers = MutableStateFlow(
        Timers(
            sleepStart = prefs.getLong("sleepStart", 0L).takeIf { it > 0 },
            breastStart = prefs.getLong("breastStart", 0L).takeIf { it > 0 },
            breastSide = prefs.getString("breastSide", null)
        )
    )
    val timers: StateFlow<Timers> = _timers

    private val _baby = MutableStateFlow(
        Baby(prefs.getString("babyName", "") ?: "", prefs.getString("babyBirth", "") ?: "")
    )
    val baby: StateFlow<Baby> = _baby

    private fun now() = System.currentTimeMillis()
    private fun add(e: Event) { viewModelScope.launch { dao.insert(e) } }

    private fun saveTimers(t: Timers) {
        _timers.value = t
        prefs.edit()
            .putLong("sleepStart", t.sleepStart ?: 0L)
            .putLong("breastStart", t.breastStart ?: 0L)
            .putString("breastSide", t.breastSide)
            .apply()
    }

    // ----- breastfeeding -----
    fun startBreast(side: String) = saveTimers(_timers.value.copy(breastStart = now(), breastSide = side))
    fun stopBreast() {
        val t = _timers.value
        val s = t.breastStart ?: return
        add(Event(type = Type.BREAST, start = s, end = now(), side = t.breastSide ?: "L"))
        saveTimers(t.copy(breastStart = null, breastSide = null))
    }
    fun addBreastManual(side: String, minutes: Double) {
        val n = now()
        add(Event(type = Type.BREAST, start = n - (minutes * Analytics.MIN).toLong(), end = n, side = side))
    }

    // ----- sleep -----
    fun startSleep() = saveTimers(_timers.value.copy(sleepStart = now()))
    fun stopSleep() {
        val t = _timers.value
        val s = t.sleepStart ?: return
        add(Event(type = Type.SLEEP, start = s, end = now()))
        saveTimers(t.copy(sleepStart = null))
    }
    fun addSleepManual(minutes: Double) {
        val n = now()
        add(Event(type = Type.SLEEP, start = n - (minutes * Analytics.MIN).toLong(), end = n))
    }

    // ----- bottle, diaper, growth -----
    fun addBottle(kind: String, ml: Int, minutesAgo: Int) =
        add(Event(type = Type.BOTTLE, start = now() - minutesAgo * Analytics.MIN, ml = ml, kind = kind))

    fun addDiaper(kind: String, minutesAgo: Int) =
        add(Event(type = Type.DIAPER, start = now() - minutesAgo * Analytics.MIN, kind = kind))

    fun addGrowth(weight: Double?, height: Double?, head: Double?) =
        add(Event(type = Type.GROWTH, start = now(), weight = weight, height = height, head = head))

    fun delete(id: Long) { viewModelScope.launch { dao.delete(id) } }

    // ----- profile -----
    fun setBaby(name: String, birth: String) {
        _baby.value = Baby(name, birth)
        prefs.edit().putString("babyName", name).putString("babyBirth", birth).apply()
    }

    // ----- data tools -----
    fun loadDemo() {
        viewModelScope.launch {
            dao.clear()
            dao.insertAll(Demo.events())
            val birth = java.time.LocalDate.now().minusDays(45).toString()
            setBaby("نمونه", birth)
            saveTimers(Timers())
        }
    }

    fun wipe() {
        viewModelScope.launch { dao.clear() }
        saveTimers(Timers())
    }

    fun exportJson(): String {
        val arr = JSONArray()
        events.value.forEach { e ->
            arr.put(JSONObject().apply {
                put("type", e.type); put("start", e.start)
                e.end?.let { put("end", it) }; e.side?.let { put("side", it) }
                e.ml?.let { put("ml", it) }; e.kind?.let { put("kind", it) }
                e.weight?.let { put("weight", it) }; e.height?.let { put("height", it) }
                e.head?.let { put("head", it) }
            })
        }
        return JSONObject().put("v", 1)
            .put("baby", JSONObject().put("name", _baby.value.name).put("birth", _baby.value.birth))
            .put("events", arr).toString()
    }

    /** Returns false when the text is not a valid backup. Replaces all existing events. */
    fun importJson(text: String): Boolean = try {
        val o = JSONObject(text)
        val arr = o.getJSONArray("events")
        val list = (0 until arr.length()).map { i ->
            val j = arr.getJSONObject(i)
            Event(
                type = j.getString("type"), start = j.getLong("start"),
                end = if (j.has("end")) j.getLong("end") else null,
                side = if (j.has("side")) j.getString("side") else null,
                ml = if (j.has("ml")) j.getInt("ml") else null,
                kind = if (j.has("kind")) j.getString("kind") else null,
                weight = if (j.has("weight")) j.getDouble("weight") else null,
                height = if (j.has("height")) j.getDouble("height") else null,
                head = if (j.has("head")) j.getDouble("head") else null
            )
        }
        o.optJSONObject("baby")?.let { setBaby(it.optString("name"), it.optString("birth")) }
        viewModelScope.launch { dao.clear(); dao.insertAll(list) }
        true
    } catch (e: Exception) {
        false
    }
}
