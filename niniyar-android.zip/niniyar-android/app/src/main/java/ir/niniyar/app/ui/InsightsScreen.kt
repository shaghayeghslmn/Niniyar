package ir.niniyar.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ir.niniyar.app.MainViewModel
import ir.niniyar.app.analytics.Analytics
import ir.niniyar.app.data.Type
import ir.niniyar.app.util.Fmt

@Composable
fun InsightsScreen(vm: MainViewModel, contentPadding: PaddingValues) {
    val events by vm.events.collectAsStateWithLifecycle()
    val tones = LocalTones.current
    var range by rememberSaveable { mutableIntStateOf(7) }
    val now = System.currentTimeMillis()
    val r = remember(events, range) { Analytics.analyze(events, range, now) }

    LazyColumn(
        contentPadding = PaddingValues(
            start = 14.dp, end = 14.dp,
            top = contentPadding.calculateTopPadding() + 10.dp,
            bottom = contentPadding.calculateBottomPadding() + 16.dp
        ),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column(Modifier.padding(horizontal = 4.dp)) {
                Text("تحلیل الگوها", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                Muted("بر پایه ثبت‌های خودتان")
            }
        }
        item {
            Seg(listOf(7 to "۷ روز", 14 to "۱۴ روز", 30 to "۳۰ روز"), range, { range = it })
        }

        if (r.activeDays < 2) {
            item {
                NCard {
                    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("📊", fontSize = 34.sp)
                        Text("برای دیدن الگوها به چند روز ثبت نیاز است", fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                        Spacer(Modifier.height(6.dp))
                        Muted("دست‌کم دو روز ثبت کنید، یا با داده نمونه نمودارها را ببینید.")
                        Spacer(Modifier.height(12.dp))
                        Button({ vm.loadDemo() }) { Text("بارگذاری داده نمونه") }
                    }
                }
            }
            return@LazyColumn
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Kpi("میانگین خواب روزانه", Fmt.hrs(r.sleepAvg), trend(r.sleepAvg.toDouble(), r.prevSleepAvg?.toDouble()), Modifier.weight(1f))
                    Kpi("میانگین شیردهی روزانه", "${Fmt.num(r.feedsAvg, 1)} بار", trend(r.feedsAvg, r.prevFeedsAvg), Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Kpi("میانگین فاصله شیردهی", r.interval?.let { Fmt.dur(it) } ?: "—", null, Modifier.weight(1f))
                    Kpi("میانگین بیداری بین دو خواب", r.wake?.let { Fmt.dur(it) } ?: "—", null, Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Kpi("طولانی‌ترین خواب شبانه", r.stretch?.let { Fmt.dur(it) } ?: "—", null, Modifier.weight(1f))
                    Kpi("میانگین پوشک روزانه", "${Fmt.num(r.diaperAvg, 1)} بار", null, Modifier.weight(1f))
                }
            }
        }

        item {
            NCard {
                CardTitle("خواب روزانه")
                StackedBars(
                    r.days, { listOf(it.night / Analytics.H.toFloat(), it.day / Analytics.H.toFloat()) },
                    listOf(tones.night, tones.sleep), { "${Fmt.num(it, 0)} ساعت" }
                )
                Legend(tones.night to "شب (۱۹ تا ۷)", tones.sleep to "روز")
            }
        }
        item {
            NCard {
                CardTitle("شیردهی روزانه")
                StackedBars(
                    r.days, { listOf(it.breast.toFloat(), it.bottle.toFloat()) },
                    listOf(tones.breast, tones.bottle), { "${Fmt.num(it, 0)} بار" }
                )
                Legend(tones.breast to "شیر مادر", tones.bottle to "شیشه")
                if (r.mlAvg > 0) Muted("میانگین شیشه: ${Fmt.num(Math.round(r.mlAvg))} میلی‌لیتر در روز", 12)
            }
        }
        item {
            NCard {
                CardTitle("پوشک روزانه")
                StackedBars(
                    r.days, { listOf(it.wet.toFloat(), it.dirty.toFloat()) },
                    listOf(tones.growth, tones.diaper), { "${Fmt.num(it, 0)} بار" }
                )
                Legend(tones.growth to "خیس", tones.diaper to "کثیف")
            }
        }

        item {
            val maxS = (r.sleepByHour.maxOrNull() ?: 1L).coerceAtLeast(1L)
            val maxF = (r.feedsByHour.maxOrNull() ?: 1).coerceAtLeast(1)
            NCard {
                CardTitle("ساعت‌شناسی: کی می‌خوابد و کی می‌خورد؟")
                Muted("خواب", 12)
                HourStrip(r.sleepByHour.map { it.toFloat() / maxS }, tones.sleep)
                Spacer(Modifier.height(8.dp))
                Muted("شیردهی", 12)
                HourStrip(r.feedsByHour.map { it.toFloat() / maxF }, tones.breast)
                Row(Modifier.fillMaxWidth().padding(top = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    listOf(0, 6, 12, 18, 23).forEach { Muted(Fmt.num(it), 11) }
                }
                Spacer(Modifier.height(6.dp))
                Muted("هر خانه یک ساعت از شبانه‌روز است؛ هرچه پررنگ‌تر، آن ساعت در این بازه بیشتر تکرار شده.", 12)
            }
        }

        item {
            val maxS = (r.sleepByHour.maxOrNull() ?: 0L)
            val maxF = (r.feedsByHour.maxOrNull() ?: 0)
            val lines = ArrayList<Pair<String, String>>()
            lines.add("😴" to "میانگین خواب ${Fmt.hrs(r.sleepAvg)} در شبانه‌روز است" +
                (r.prevSleepAvg?.let { " (دوره قبل: ${Fmt.hrs(it)})." } ?: "."))
            r.stretch?.let { lines.add("🌙" to "طولانی‌ترین خواب پیوسته شبانه معمولاً حدود ${Fmt.dur(it)} است.") }
            r.wake?.let { lines.add("⏰" to "بیداری‌ها معمولاً حدود ${Fmt.dur(it)} طول می‌کشد؛ نزدیک این زمان، نشانه‌های خواب‌آلودگی را بیشتر زیر نظر بگیرید.") }
            r.interval?.let { lines.add("🍼" to "شیردهی به‌طور میانگین هر ${Fmt.dur(it)} یک‌بار انجام شده است.") }
            if (maxF > 1) {
                val h = r.feedsByHour.indexOf(maxF)
                lines.add("🕒" to "شلوغ‌ترین ساعت شیردهی، بین ${Fmt.num(h)} تا ${Fmt.num((h + 1) % 24)} است.")
            }
            if (maxS > Analytics.H / 2) {
                val h = r.sleepByHour.indexOf(maxS)
                lines.add("💤" to "بیشترین خواب در بازه ساعت ${Fmt.num(h)} تا ${Fmt.num((h + 1) % 24)} دیده می‌شود.")
            }
            NCard {
                CardTitle("نتیجه‌گیری")
                lines.forEach { (e, t) ->
                    Row(Modifier.padding(vertical = 5.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(e, fontSize = 18.sp)
                        Text(t, fontSize = 14.sp)
                    }
                }
            }
        }

        item {
            val pts = events.filter { it.type == Type.GROWTH && it.weight != null }
                .sortedBy { it.start }.map { it.start to (it.weight ?: 0.0) }
            NCard {
                CardTitle("رشد")
                if (pts.size >= 2) {
                    LineChart(pts, tones.growth)
                    Muted("وزن بر حسب کیلوگرم. افزایش وزن از اولین تا آخرین ثبت: ${Fmt.num(pts.last().second - pts.first().second, 2)} کیلوگرم.", 12)
                } else Muted("دست‌کم دو بار وزن ثبت کنید تا نمودار رشد نمایش داده شود.")
                Spacer(Modifier.height(6.dp))
                Muted("این نمودار فقط روند ثبت‌های شماست و منحنی استاندارد رشد نیست. برای ارزیابی رشد با پزشک یا مرکز بهداشت مشورت کنید.", 12)
            }
        }
    }
}

@Composable
private fun Muted(text: String, size: Int = 13) =
    Text(text, fontSize = size.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

@Composable
private fun CardTitle(text: String) {
    Text(text, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    Spacer(Modifier.height(10.dp))
}

private class Trend(val text: String, val up: Boolean?)

private fun trend(cur: Double, prev: Double?): Trend? {
    if (prev == null || prev <= 0.0) return null
    val p = (cur - prev) / prev * 100
    if (Math.abs(p) < 3) return Trend("تقریباً بدون تغییر", null)
    return Trend((if (p > 0) "▲ " else "▼ ") + Fmt.num(Math.abs(p)) + "٪ نسبت به دوره قبل", p > 0)
}

@Composable
private fun Kpi(label: String, value: String, trend: Trend?, modifier: Modifier) {
    val tones = LocalTones.current
    Column(
        modifier.clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surface).padding(12.dp)
    ) {
        Text(value, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
        Muted(label, 12)
        if (trend != null) {
            Text(
                trend.text, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                color = when (trend.up) { true -> tones.diaper; false -> tones.bottle; null -> MaterialTheme.colorScheme.onSurfaceVariant }
            )
        }
    }
}

@Composable
private fun Legend(vararg items: Pair<Color, String>) {
    Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        items.forEach { (c, t) ->
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Dot(c); Muted(t, 12)
            }
        }
    }
}

@Composable
private fun HourStrip(values: List<Float>, color: Color) {
    val ring = LocalTones.current.ring
    Row(Modifier.fillMaxWidth().height(26.dp).padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
        values.forEach { v ->
            Box(Modifier.weight(1f).height(22.dp).clip(RoundedCornerShape(4.dp)).background(ring)) {
                Box(Modifier.matchParentSize().alpha(v.coerceIn(0f, 1f)).background(color))
            }
        }
    }
}

