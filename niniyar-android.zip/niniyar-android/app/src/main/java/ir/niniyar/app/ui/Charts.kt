package ir.niniyar.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.niniyar.app.analytics.Analytics
import ir.niniyar.app.data.Event
import ir.niniyar.app.data.Type
import ir.niniyar.app.util.Fmt
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

/** 24-hour clock for today: sleep as arcs, feeds and diapers as dots, a hand for "now". */
@Composable
fun DayRing(events: List<Event>, sleepStart: Long?, now: Long, modifier: Modifier = Modifier.size(190.dp)) {
    val tones = LocalTones.current
    val ink = MaterialTheme.colorScheme.onSurface
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    val surface = MaterialTheme.colorScheme.surface
    val tm = rememberTextMeasurer()
    val a = Analytics.dayStart(0, now)
    val b = Analytics.nextDay(a)

    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 16.dp.toPx()
            val c = Offset(size.width / 2, size.height / 2)
            val r = size.minDimension / 2 - 20.dp.toPx()
            fun deg(ts: Long) = (ts - a).toFloat() / (b - a) * 360f - 90f
            fun pt(ts: Long, rad: Float): Offset {
                val t = Math.toRadians(deg(ts).toDouble())
                return Offset(c.x + rad * cos(t).toFloat(), c.y + rad * sin(t).toFloat())
            }

            drawCircle(tones.ring, radius = r, center = c, style = Stroke(stroke))

            // hour labels at 0, 6, 12, 18
            val labelStyle = TextStyle(fontSize = 9.sp, color = muted)
            listOf(0, 6, 12, 18).forEach { h ->
                val ts = a + h * Analytics.H
                val p = pt(ts, r + stroke / 2 + 8.dp.toPx())
                val layout = tm.measure(Fmt.num(h), labelStyle)
                drawText(layout, topLeft = Offset(p.x - layout.size.width / 2f, p.y - layout.size.height / 2f))
            }

            // sleep arcs
            val spans = events.filter { it.type == Type.SLEEP && it.end != null && it.end > a && it.start < b }
                .map { maxOf(it.start, a) to minOf(it.end ?: it.start, b) }
                .toMutableList()
            if (sleepStart != null) spans.add(maxOf(sleepStart, a) to minOf(now, b))
            spans.forEach { (s, e) ->
                val sweep = max((e - s).toFloat() / (b - a) * 360f, 2f)
                drawArc(
                    color = tones.sleep, startAngle = deg(s), sweepAngle = sweep, useCenter = false,
                    topLeft = Offset(c.x - r, c.y - r), size = Size(2 * r, 2 * r), style = Stroke(stroke)
                )
            }

            // feeds (outer dots) and diapers (inner dots)
            events.forEach { e ->
                if (e.start < a || e.start >= b) return@forEach
                when (e.type) {
                    Type.BREAST, Type.BOTTLE -> {
                        val col = if (e.type == Type.BREAST) tones.breast else tones.bottle
                        val p = pt(e.start, r - stroke / 2 - 7.dp.toPx())
                        drawCircle(surface, 5.5.dp.toPx(), p)
                        drawCircle(col, 4.dp.toPx(), p)
                    }
                    Type.DIAPER -> {
                        val p = pt(e.start, r - stroke / 2 - 21.dp.toPx())
                        drawCircle(surface, 5.5.dp.toPx(), p)
                        drawCircle(tones.diaper, 4.dp.toPx(), p)
                    }
                }
            }

            // "now" hand
            drawLine(
                ink, pt(now, r - stroke / 2 - 30.dp.toPx()), pt(now, r + stroke / 2 + 2.dp.toPx()),
                strokeWidth = 2.dp.toPx(), cap = StrokeCap.Round
            )
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(Fmt.time(now), fontSize = 22.sp, color = ink, style = MaterialTheme.typography.titleLarge)
            Text("امروز", fontSize = 11.sp, color = muted)
        }
    }
}

/** Stacked bars, one per day. Oldest day on the right so time reads in the same direction as the text. */
@Composable
fun StackedBars(
    days: List<Analytics.Day>,
    parts: (Analytics.Day) -> List<Float>,
    colors: List<Color>,
    maxLabel: (Float) -> String,
    modifier: Modifier = Modifier.fillMaxWidth().height(150.dp)
) {
    val tm = rememberTextMeasurer()
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    val line = MaterialTheme.colorScheme.outlineVariant
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val pt = 16.dp.toPx()
        val pb = 22.dp.toPx()
        val n = days.size
        val bw = w / n
        val totals = days.map { parts(it).sum() }
        val mx = max(totals.maxOrNull() ?: 1f, 1e-3f)
        val style = TextStyle(fontSize = 9.sp, color = muted)

        drawLine(line, Offset(0f, h - pb), Offset(w, h - pb), 1.dp.toPx())
        drawText(tm.measure(maxLabel(mx), style), topLeft = Offset(0f, 0f))

        val step = Math.ceil(n / 7.0).toInt().coerceAtLeast(1)
        days.forEachIndexed { k, d ->
            val x = w - (k + 1) * bw
            var y = h - pb
            parts(d).forEachIndexed { j, v ->
                val bh = v / mx * (h - pb - pt)
                if (bh > 0.5f) {
                    y -= bh
                    drawRoundRect(
                        colors[j], Offset(x + bw * 0.16f, y), Size(bw * 0.68f, bh),
                        CornerRadius(2.dp.toPx())
                    )
                }
            }
            if (n <= 7 || k % step == (n - 1) % step) {
                val lay = tm.measure(Fmt.dayShort(d.start), style)
                drawText(lay, topLeft = Offset(x + bw / 2 - lay.size.width / 2f, h - pb + 5.dp.toPx()))
            }
        }
    }
}

/** Line chart for (timestamp, value) points, newest on the left. */
@Composable
fun LineChart(points: List<Pair<Long, Double>>, color: Color, modifier: Modifier = Modifier.fillMaxWidth().height(150.dp)) {
    val tm = rememberTextMeasurer()
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    val ink = MaterialTheme.colorScheme.onSurface
    val line = MaterialTheme.colorScheme.outlineVariant
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val pb = 22.dp.toPx()
        val pt = 20.dp.toPx()
        val padX = 18.dp.toPx()
        val x0 = points.minOf { it.first }.toDouble()
        var x1 = points.maxOf { it.first }.toDouble()
        if (x1 == x0) x1 = x0 + Analytics.H * 24
        var y0 = points.minOf { it.second }
        var y1 = points.maxOf { it.second }
        val pad = (y1 - y0) * 0.2 + 0.05
        y0 -= pad; y1 += pad
        fun px(t: Long) = (w - padX - (t - x0) / (x1 - x0) * (w - 2 * padX)).toFloat()
        fun py(v: Double) = (h - pb - (v - y0) / (y1 - y0) * (h - pb - pt)).toFloat()

        drawLine(line, Offset(0f, h - pb), Offset(w, h - pb), 1.dp.toPx())
        val path = Path()
        points.forEachIndexed { i, p ->
            if (i == 0) path.moveTo(px(p.first), py(p.second)) else path.lineTo(px(p.first), py(p.second))
        }
        drawPath(path, color, style = Stroke(2.5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
        points.forEachIndexed { i, p ->
            val c = Offset(px(p.first), py(p.second))
            drawCircle(color, 4.dp.toPx(), c)
            if (i == 0 || i == points.lastIndex || points.size <= 5) {
                val v = tm.measure(Fmt.num(p.second, 1), TextStyle(fontSize = 10.sp, color = ink))
                drawText(v, topLeft = Offset(c.x - v.size.width / 2f, c.y - v.size.height - 6.dp.toPx()))
                val d = tm.measure(Fmt.dayShort(p.first), TextStyle(fontSize = 9.sp, color = muted))
                drawText(d, topLeft = Offset(c.x - d.size.width / 2f, h - pb + 5.dp.toPx()))
            }
        }
    }
}
