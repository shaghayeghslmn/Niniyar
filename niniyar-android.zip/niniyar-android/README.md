# نی‌نی‌یار (NiniYar) — Persian baby tracker for Android

Native Android app (Kotlin, Jetpack Compose, Room). Persian UI, right-to-left layout,
Jalali dates and Persian digits. Everything is stored on the device.

## Run it
1. Install Android Studio (Koala or newer) with an Android 14 (API 34) SDK.
2. File → Open → select this folder. Let Gradle sync. If Android Studio offers to
   create the Gradle wrapper, accept (this archive ships only `gradle-wrapper.properties`).
3. Pick an emulator or a phone (Android 8.0 / API 26 or newer) and press Run.
4. Open the "تحلیل" tab and tap "بارگذاری داده نمونه" to see the analytics with 14 days of sample data.

## Structure
- `data/` Room entity (`Event`), DAO, database.
- `analytics/Analytics.kt` all statistics, pure Kotlin (unit-tested in `app/src/test`).
- `analytics/Demo.kt` sample-data generator.
- `ui/` Compose screens: Today, Insights, Settings, log sheets, canvas charts (day ring, bars, line).
- `util/Fmt.kt` Persian numbers, Jalali dates, durations, digit-tolerant number parsing.
- `MainViewModel.kt` timers, logging, backup/restore (JSON via clipboard).

## Status
Written without access to an Android SDK, so it has not been compiled or run yet.
Expect to fix a few small compile errors on first build. Run `./gradlew test` for the analytics tests.

## Known gaps / next steps
- Strings are inline Persian; move to `res/values/strings.xml` before adding languages.
- Font is the system default. To use Vazirmatn, add the TTF files to `res/font/` and set a `FontFamily` in the theme typography.
- Birth date uses the Material date picker (Gregorian); a Jalali picker is a follow-up.
- No growth percentile curves (needs official WHO tables), no reminders/notifications, no cloud sync or multi-caregiver sharing.
- App icon not included (default launcher icon is used).
